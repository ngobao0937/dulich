<footer class="main-footer">
    {{-- <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.2.0
    </div> --}}
    <strong>Copyright © 2025 <a href="#" target="_blank">www.website.vn</a>.</strong> All rights reserved.
</footer>
